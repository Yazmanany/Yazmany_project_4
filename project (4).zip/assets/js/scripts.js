$(function() {
 var $searchInput;
  var $title;
  var $caption;
  
  

  
  $('#searchInput').on('keyup change', function(){

   
    $searchInput = $('#searchInput').val().toLowerCase();


    
    $('.gallery-item').each(function() {
      $title = $(this).find('img').attr('alt').toLowerCase();
      $caption = $(this).find('a').attr('data-title').toLowerCase();

      $(this).each(function() {

        if ($caption.indexOf($searchInput) === -1) {
          $(this).hide();
        } else {
          $(this).show();
        }


      });

    }); 
    console.log($caption);

  }); 

}); 